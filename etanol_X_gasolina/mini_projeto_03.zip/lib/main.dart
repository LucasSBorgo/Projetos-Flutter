import 'package:flutter/material.dart';
import 'Home.dart';

void main() {
 runApp(const MaterialApp(
   home: Home(),
   title: "Mini Projeto 04",
   debugShowCheckedModeBanner: false,
 ));
}